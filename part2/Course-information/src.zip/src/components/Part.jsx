const Part = (props) => {
  console.log(props, "Part");
  const {part, exercises} = props

  return (
    <p>
      {part} {exercises}
    </p>
  );
};

export default Part;
