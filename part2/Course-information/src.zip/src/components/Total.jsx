const Total = (props) => {
  console.log(props, "Total");
  const { parts } = props;
  console.log(parts, "Total");

  return (
    <p>
      Number of exercises{" "}
      {parts.reduce((sum, part) => (sum += part.exercises), 0)}
    </p>
  );
};
export default Total;
