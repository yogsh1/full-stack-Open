import Content from "./Content";
import Header from "./Header";
import Total from "./Total";
const Course = (props) => {
  console.log(props, "1111111111111");
  const { course } = props;
  console.log(course, "22222222222");
  return (
    <div>
      <Header course={course[0].name} />
      <Content parts={course[0].parts} />

      <Header
        course={course.map((item) => (
          <div>{item.name}</div>
        ))}
      />
      <Content parts={course.map((item) => item.parts)} />
      {/* <Total parts={course[0].parts} /> */}
    </div>
  );
};

export default Course;
