import Part from "./Part";

const Content = (props) => {
  console.log(props, "Content65");
  const { parts } = props;

  console.log(parts, "000000000000");

  return (
    <>
      {/* {course.parts[0]} */}
      
      <Part
       part={parts.map((item) => item.name)} 
       exercises={parts.map((item) => item.exercises)}
      />
      {/* <Part part={parts[1].name} exercises={parts[1].exercises} />
      <Part part={parts[2].name} exercises={parts[2].exercises} /> */}
      
    </>
  );
};
export default Content;
